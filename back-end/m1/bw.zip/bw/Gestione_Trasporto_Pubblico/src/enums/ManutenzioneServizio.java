package enums;

public enum ManutenzioneServizio {
	MANUTENZIONE,
	SERVIZIO
}
