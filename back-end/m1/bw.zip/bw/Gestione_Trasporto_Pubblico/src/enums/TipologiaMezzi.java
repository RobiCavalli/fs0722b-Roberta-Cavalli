package enums;

public enum TipologiaMezzi {
	TRAM,
	AUTOBUS
}
