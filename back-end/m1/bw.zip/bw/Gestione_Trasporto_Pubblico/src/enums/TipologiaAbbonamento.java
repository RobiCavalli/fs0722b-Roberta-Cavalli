package enums;

public enum TipologiaAbbonamento {
	SETTIMANALE,
	MENSILE,
	ANNUALE
}
