package enums;

public enum TipologiaBiglietto {
	URBANO,
	EXTRAURBANO
}
