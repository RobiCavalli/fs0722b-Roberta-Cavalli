package enums;

public enum StatoDistributoreAutomatico {
	ATTIVO,
	FUORISERVIZIO
}
